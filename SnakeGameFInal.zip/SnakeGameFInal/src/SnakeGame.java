
public class SnakeGame {
    public SnakeGame() {
        new GameFrame();
    }


}
