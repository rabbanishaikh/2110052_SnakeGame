import java.util.HashMap;

public class IDandPasswords {

    HashMap<String,String> logininfo = new HashMap<String,String>();
    IDandPasswords(){
        logininfo.put("Password","123");
        logininfo.put("Password","password");
        logininfo.put("Password","abc");
    }
    protected HashMap getLoginInfo(){
        return logininfo;
    }


}
